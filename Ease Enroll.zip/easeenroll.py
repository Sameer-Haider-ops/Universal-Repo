"""
EaseEnroll - Simplified Enrollment System, That Saves You Chaos Later On
Habib University edition (PSCS shopping-cart style planner)

Terminal-based. Pure Python: NO imports, NO external libraries.

Two modes share ONE cart of pending changes (like the PSCS shopping cart):
  * Analyze Mode : course info, weekly calendar, eligibility, recommendations
  * Enroll Mode  : add / drop courses

HABIB UNIVERSITY REFERENCES (HU Course Catalog 2025-26 + iSciM / Minors pages)
  - Course codes use HU's format: PREFIX + 3 digits (e.g. BIO 101, MATH 101).
  - Credit load: min 12 (full-time), max 20. Above 20 needs a petition
    (CGPA 3.0+); below 12 without approval -> Academic Warning.
  - Instructor names / office hours / rooms come from your screenshots.

DATA YOU SHOULD DOUBLE-CHECK
  - A '*' after a code means the code and/or credits could NOT be confirmed
    in the HU catalog pages I could read (see the "verify" field).
  - Lecture timings, offered semesters and "TBA" instructors are PLACEHOLDERS.
  - HSSC rules ("not_hssc" / "need_hssc") exist ONLY for chemistry, bio and
    physics-related courses. They and requirements marked src="house" are
    EaseEnroll's own rules, not HU catalog rules.
"""

# ----------------------------------------------------------------------
# CONFIG
# ----------------------------------------------------------------------
MIN_CREDITS = 12   # HU full-time minimum
MAX_CREDITS = 20   # HU maximum allowable course load
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
# HSSC placement rules apply ONLY to chemistry-, bio- and physics-related courses
HSSC_SUBJECTS = ["Chemistry", "Biology", "Physics"]


def hm(h, m=0):
    """24h clock -> minutes since midnight."""
    return h * 60 + m


def fmt(mins):
    """minutes since midnight -> '1:00 PM'."""
    h = mins // 60
    m = mins % 60
    suffix = "AM" if h < 12 else "PM"
    h12 = h % 12
    if h12 == 0:
        h12 = 12
    return f"{h12}:{m:02d} {suffix}"


def slots(days, start, end, kind="Lecture"):
    """Build timing tuples (day, start, end, kind) for several days."""
    return [(d, start, end, kind) for d in days]


def req(courses, hssc=None, src="HU"):
    """
    One prerequisite requirement. Satisfied if ANY listed course is completed
    OR ANY listed HSSC subject was taken.  src = 'HU' (catalog) or 'house'.
    """
    return {"courses": courses, "hssc": hssc or [], "src": src}


def emit(line, out=None):
    """Print a line, or append it to `out` (used by the GUI)."""
    if out is None:
        print(line)
    else:
        out.append(line)


MW = ["Monday", "Wednesday"]
TT = ["Tuesday", "Thursday"]

# ----------------------------------------------------------------------
# INSTRUCTORS (dictionary) - office hours taken from the screenshots
# "tas" holds instructor ids -> used by the recursive fetchInstructorInfo()
# ----------------------------------------------------------------------
INSTRUCTORS = {
    "afzal": {
        "name": "Afzal Azim", "ratings": [], "tas": [],
        "office_hours": [("Thursday", hm(13), hm(14), "(Pod: Meeting Room | Room: C-114)")],
    },
    "unaiza": {
        "name": "Unaiza Ahsan", "ratings": [], "tas": ["aisha"],  # Aisha = lab instructor, modeled as TA
        "office_hours": [("Monday", hm(13), hm(14), "(Pod: E-114 | Room: E-119)")],
    },
    "aisha": {
        "name": "Aisha Batool", "ratings": [], "tas": [],
        "office_hours": [
            ("Monday", hm(10), hm(12), "(Pod: W-300 | Room: W-300)"),
            ("Wednesday", hm(10), hm(12), "Room W-300"),
        ],
    },
    "iqra": {
        "name": "Iqra Kakar", "ratings": [], "tas": [],
        "office_hours": [("Friday", hm(12, 45), hm(14), "(Pod: N-400 | Room: N-415-3)")],
    },
    "farhan": {
        "name": "Muhammad Farhan", "ratings": [], "tas": [],
        "office_hours": [("Monday", hm(16, 30), hm(17, 30), "(Pod: C-203 | Room: C-214)")],
    },
    "musab": {
        "name": "Musab Waqar", "ratings": [], "tas": [],
        "office_hours": [("Monday", hm(14), hm(15), "(Pod: N-400 | Room: N-413-1)")],
    },
    "mehr": {
        "name": "Syeda Mehr", "ratings": [], "tas": [],
        "office_hours": [("Monday", hm(13), hm(14), "(Pod: N-400 | Room: N-411-1)")],
    },
    "vijay": {
        "name": "Vijay Kumar", "ratings": [], "tas": [],
        "office_hours": [("Tuesday", hm(11, 30), hm(12, 30), "(Pod: N-218 | Room: N-232)")],
    },
    # Placeholder for courses whose instructor wasn't in the screenshots
    "tba": {"name": "TBA (to be announced)", "ratings": [], "tas": [], "office_hours": []},
}

# ----------------------------------------------------------------------
# COURSES (dictionary, keyed by HU-style course code)
#   verify    : '' if code+credits are confirmed in HU pages, else what to check
#   sems      : semesters in which the course is offered (placeholder)
#   not_hssc  : eligible ONLY IF you did NOT take these subjects in HSSC
#   need_hssc : eligible ONLY IF you DID take these subjects in HSSC
#   requires  : list of req(...) - catalog prerequisites (src 'HU') or house rules
# ----------------------------------------------------------------------
COURSES = {
    # --- Natural science / math (iSciM) ---
    "CHEM 101": {
        "name": "Introduction to Chemistry", "section": "L1", "credits": 3,
        "verify": "code, credits", "sems": [1, 2, 3, 4], "instructor": "afzal",
        "lectures": slots(TT, hm(9), hm(10, 30)),
        "not_hssc": ["Chemistry"], "need_hssc": [], "requires": [],
    },
    "MATH 101": {
        "name": "Modeling Our World (Calculus I)", "section": "L8", "credits": 4,
        "verify": "", "sems": [1, 2, 3, 4], "instructor": "vijay",
        "lectures": slots(MW, hm(9), hm(10, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "BIO 101": {
        "name": "Cell Biology and Public Health", "section": "L1", "credits": 4,
        "verify": "", "sems": [1, 2, 3, 4], "instructor": "tba",
        "lectures": slots(TT, hm(10, 30), hm(12)) + slots(["Friday"], hm(13), hm(16), "Lab (BIO 101L)"),
        "not_hssc": ["Biology"], "need_hssc": [], "requires": [],
    },
    "ENVS 102": {
        "name": "Introduction to Environmental Systems", "section": "L2", "credits": 3,
        "verify": "", "sems": [1, 2, 3, 4, 5, 6], "instructor": "musab",
        "lectures": slots(TT, hm(12), hm(13, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "BIO 111": {
        "name": "Food and Nutrition", "section": "L1", "credits": 4,
        "verify": "", "sems": [3, 4, 5, 6], "instructor": "tba",
        "lectures": slots(TT, hm(9, 30), hm(11)) + slots(["Friday"], hm(14), hm(17), "Lab (BIO 111L)"),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "BTEC 101": {
        "name": "Introduction to Biotechnology", "section": "L1", "credits": 3,
        "verify": "", "sems": [4, 5, 6, 7, 8], "instructor": "tba",
        "lectures": slots(TT, hm(10), hm(11, 30)),
        # HU catalog: school/college-level Biology or Chemistry
        "not_hssc": [], "need_hssc": [],
        "requires": [req(["BIO 101", "CHEM 101"], ["Biology", "Chemistry"])],
    },
    # --- Computing / engineering ---
    "CS 101": {
        "name": "Computational Thinking", "section": "L1", "credits": 4,
        "verify": "code, credits", "sems": [1, 2, 3, 4], "instructor": "unaiza",
        "lectures": slots(MW, hm(10, 30), hm(12)) + slots(["Friday"], hm(10), hm(12), "Lab T1"),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "DATA 201": {
        "name": "Reasoning with Data", "section": "L1", "credits": 3,
        "verify": "code, credits", "sems": [3, 4, 5, 6], "instructor": "tba",
        "lectures": slots(MW, hm(11), hm(12, 30)),
        "not_hssc": [], "need_hssc": [],
        "requires": [req(["CS 101"], [], "house")],
    },
    "EE 112": {
        "name": "Electric Circuits I", "section": "L4", "credits": 2,
        "verify": "", "sems": [3, 4, 5, 6], "instructor": "farhan",
        "lectures": slots(TT, hm(15, 30), hm(16, 30)),
        "not_hssc": [], "need_hssc": ["Physics"],
        "requires": [req(["MATH 101"], [], "house")],
    },
    # --- Habib Liberal Core / humanities / social science ---
    "CORE 101": {
        "name": "Rhetoric and Communication", "section": "S13", "credits": 3,
        "verify": "credits", "sems": [1, 2, 3, 4], "instructor": "mehr",
        "lectures": slots(MW, hm(12), hm(13, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "HLC 101": {
        "name": "HLC I", "section": "L5", "credits": 3,
        "verify": "code, credits", "sems": [1, 2], "instructor": "iqra",
        "lectures": slots(TT, hm(14), hm(15, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "PHIL 122": {
        "name": "Introduction to Western Philosophy", "section": "L1", "credits": 3,
        "verify": "credits", "sems": [1, 2, 3, 4, 5, 6], "instructor": "tba",
        "lectures": slots(MW, hm(14), hm(15, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "SDP 103": {
        "name": "Social Theory I", "section": "L1", "credits": 4,
        "verify": "", "sems": [2, 3, 4, 5], "instructor": "tba",
        "lectures": slots(MW, hm(12), hm(13, 30)),
        "not_hssc": [], "need_hssc": [], "requires": [],
    },
    "SDP 206": {
        "name": "Social Theory II", "section": "L1", "credits": 4,
        "verify": "", "sems": [3, 4, 5, 6], "instructor": "tba",
        "lectures": slots(MW, hm(15, 30), hm(17)),
        "not_hssc": [], "need_hssc": [],
        "requires": [req(["SDP 103"])],  # HU catalog: SDP 103 - Social Theory 1
    },
    "HIST 301": {
        "name": "Subaltern Studies", "section": "L1", "credits": 3,
        "verify": "code, credits", "sems": [4, 5, 6, 7], "instructor": "tba",
        "lectures": slots(TT, hm(14), hm(15, 30)),
        "not_hssc": [], "need_hssc": [],
        "requires": [req(["SDP 103"], [], "house")],
    },
}


def norm(text):
    """'bio101', 'BIO-101', 'bio 101' -> 'BIO101'."""
    return text.upper().replace(" ", "").replace("-", "")


CODE_INDEX = {norm(k): k for k in COURSES}

# ----------------------------------------------------------------------
# SESSION STATE  (the cart is the single source of truth)
# ----------------------------------------------------------------------
student = {"sem": 1, "current": 0, "hssc": [], "completed": []}
cart = []  # list of course codes (pending changes)


# ----------------------------------------------------------------------
# INPUT HELPERS
# ----------------------------------------------------------------------
def ask_int(prompt, lo, hi):
    while True:
        text = input(prompt).strip()
        if text.isdigit() and lo <= int(text) <= hi:
            return int(text)
        print(f"  Please enter a number between {lo} and {hi}.")


def ask_yes_no(prompt):
    while True:
        a = input(prompt).strip().lower()
        if a in ("y", "yes"):
            return True
        if a in ("n", "no"):
            return False
        print("  Please answer y or n.")


def ask_course(prompt):
    raw = input(prompt).strip()
    if raw == "":
        return None
    cid = CODE_INDEX.get(norm(raw))
    if cid is None:
        print("  Unknown course code (try e.g. BIO 101 or math101).")
        return None
    return cid


# ----------------------------------------------------------------------
# COURSE / ELIGIBILITY HELPERS
# ----------------------------------------------------------------------
def course_label(cid):
    c = COURSES[cid]
    star = "*" if c["verify"] else ""
    return f"{cid}{star} - {c['name']} ({c['section']})"


def available_courses():
    return [cid for cid in COURSES if student["sem"] in COURSES[cid]["sems"]]


def hssc_text(r):
    return " / ".join(r["hssc"])


def req_text(r):
    """Human-readable version of one requirement."""
    names = " OR ".join(r["courses"])
    if r["hssc"]:
        names += " (or HSSC " + hssc_text(r) + ")"
    return names


def rules_text(cid):
    """Human-readable prerequisite / HSSC rules for a course."""
    c = COURSES[cid]
    lines = []
    for subj in c["not_hssc"]:
        lines.append(f"HSSC rule: only if you did NOT take {subj} in HSSC")
    for subj in c["need_hssc"]:
        lines.append(f"HSSC rule: requires {subj} in HSSC")
    for r in c["requires"]:
        tag = "Prerequisite" if r["src"] == "HU" else "Prerequisite (house rule)"
        lines.append(f"{tag}: {req_text(r)}")
    return lines


def show_chain(cid, depth=0, out=None):
    """RECURSIVE: show the prerequisite chain of a course (prints, or fills `out`)."""
    pad = "    " * depth
    emit(f"{pad}- {course_label(cid)}", out)
    for r in COURSES[cid]["requires"]:
        tag = " [house rule]" if r["src"] == "house" else ""
        alt = f" (skip if you took HSSC {hssc_text(r)})" if r["hssc"] else ""
        emit(f"{pad}  needs{tag}{alt}:", out)
        for c in r["courses"]:
            show_chain(c, depth + 1, out)


def mark_completed(cid):
    """RECURSIVE: completing a course implies its single-option prerequisites."""
    if cid in student["completed"]:
        return
    student["completed"].append(cid)
    for r in COURSES[cid]["requires"]:
        if len(r["courses"]) == 1:
            mark_completed(r["courses"][0])


def req_satisfied(r):
    """Return a short note if requirement r is met, else None."""
    for subj in r["hssc"]:
        if subj in student["hssc"]:
            return f"satisfied via HSSC {subj}"
    for cid in r["courses"]:
        if cid in student["completed"]:
            return f"{cid} completed"
    return None


def eligibility(cid):
    """
    Returns (status, notes, missing)
      status : 'OK' | 'CONFIRM' | 'NO' | 'DONE'
      notes  : list of strings explaining the result
      missing: list of requirements still to confirm
    """
    c = COURSES[cid]
    if cid in student["completed"]:
        return "DONE", ["You already completed this course"], []
    for subj in c["not_hssc"]:
        if subj in student["hssc"]:
            return "NO", [f"You took {subj} in HSSC - this course is for students without it"], []
    for subj in c["need_hssc"]:
        if subj not in student["hssc"]:
            return "NO", [f"Requires {subj} in HSSC"], []
    notes = []
    missing = []
    for r in c["requires"]:
        ok = req_satisfied(r)
        if ok:
            notes.append(ok)
        else:
            missing.append(r)
    if missing:
        return "CONFIRM", notes, missing
    return "OK", notes, []


# ----------------------------------------------------------------------
# SCHEDULE / CONFLICT HELPERS
# ----------------------------------------------------------------------
def clashes(a, b):
    """NESTED ITERATION: overlapping timing slots between two courses."""
    found = []
    for (d1, s1, e1, k1) in COURSES[a]["lectures"]:
        for (d2, s2, e2, k2) in COURSES[b]["lectures"]:
            if d1 == d2 and s1 < e2 and s2 < e1:
                found.append((d1, max(s1, s2), min(e1, e2)))
    return found


def all_conflicts():
    """NESTED ITERATION: every cart course compared with every other."""
    found = []
    for i in range(len(cart)):
        for j in range(i + 1, len(cart)):
            for (d, s, e) in clashes(cart[i], cart[j]):
                found.append((cart[i], cart[j], d, s, e))
    return found


def show_calendar():
    print("\n=== WEEKLY CALENDAR (cart = pending changes) ===")
    if not cart:
        print("Your cart is empty - add a course in Enroll Mode first.")
        return
    lo = 24 * 60
    hi = 0
    for cid in cart:
        for (d, s, e, k) in COURSES[cid]["lectures"]:
            if s < lo:
                lo = s
            if e > hi:
                hi = e
    lo = lo // 30 * 30
    header = "Time".ljust(10)
    for d in DAYS:
        header += d[:3].ljust(11)
    print(header)
    print("-" * len(header))
    t = lo
    while t < hi:
        row = fmt(t).ljust(10)
        for d in DAYS:
            here = []
            for cid in cart:
                for (dd, s, e, k) in COURSES[cid]["lectures"]:
                    if dd == d and s < t + 30 and t < e and cid not in here:
                        here.append(cid)
            if not here:
                cell = "."
            elif len(here) == 1:
                cell = here[0]
            else:
                cell = "CLASH!"
            row += cell.ljust(11)
        print(row)
        t += 30
    conflicts = all_conflicts()
    print()
    if conflicts:
        print("CONFLICTS DETECTED:")
        for (a, b, d, s, e) in conflicts:
            print(f"  ! {a} and {b} overlap on {d}, {fmt(s)} - {fmt(e)}")
    else:
        print("No timing conflicts in your cart.")


# ----------------------------------------------------------------------
# CREDITS (always computed fresh from the cart -> cart consistency)
# ----------------------------------------------------------------------
def cart_credits():
    total = 0
    for cid in cart:
        total += COURSES[cid]["credits"]
    return total


def credit_status():
    """Returns (added, projected, level, messages); level is 'ok' | 'under' | 'over'."""
    added = cart_credits()
    projected = student["current"] + added
    if projected > MAX_CREDITS:
        level = "over"
        msgs = [f"WARNING: OVERLOAD - {projected - MAX_CREDITS} credit(s) above the HU maximum of {MAX_CREDITS}.",
                "Going over needs a petition to the Committee on Academic Standing (CGPA 3.0+)."]
    elif projected < MIN_CREDITS:
        level = "under"
        msgs = [f"WARNING: UNDERLOAD - {MIN_CREDITS - projected} credit(s) below the full-time minimum of {MIN_CREDITS}.",
                "Enrolling below 12 without approval leads to Academic Warning at HU."]
    else:
        level = "ok"
        msgs = ["Credit load is within the allowed range."]
    return added, projected, level, msgs


def credit_report():
    added, projected, level, msgs = credit_status()
    print("\n--- CREDIT SUMMARY ---")
    print(f"Current credit hours : {student['current']}")
    print(f"Cart (pending)       : +{added}")
    print(f"Projected total      : {projected}   (HU allows {MIN_CREDITS}-{MAX_CREDITS})")
    for i, m in enumerate(msgs):
        print(m if i == 0 else "         " + m)


# ----------------------------------------------------------------------
# INSTRUCTORS
# ----------------------------------------------------------------------
def rating_text(ins):
    if not ins["ratings"]:
        return "Not rated yet"
    avg = sum(ins["ratings"]) / len(ins["ratings"])
    return f"{round(avg, 1)}/5 ({len(ins['ratings'])} rating(s))"


def fetchInstructorInfo(iid, depth=0, out=None):
    """RECURSIVE: show instructor details, then call itself for each TA."""
    ins = INSTRUCTORS[iid]
    pad = "    " * depth
    role = "Instructor" if depth == 0 else "Teaching Assistant"
    emit(f"{pad}{role}: {ins['name']}", out)
    emit(f"{pad}  Rating: {rating_text(ins)}", out)
    if ins["office_hours"]:
        emit(f"{pad}  Office hours:", out)
        for (day, s, e, where) in ins["office_hours"]:
            emit(f"{pad}    {day} {fmt(s)} - {fmt(e)}  {where}", out)
    else:
        emit(f"{pad}  Office hours: not available yet", out)
    if ins["tas"]:
        emit(f"{pad}  Teaching Assistants:", out)
        for ta in ins["tas"]:
            fetchInstructorInfo(ta, depth + 1, out)


def pick_instructor():
    ids = [k for k in INSTRUCTORS if k != "tba"]
    for i, k in enumerate(ids, 1):
        print(f"  {i}. {INSTRUCTORS[k]['name']}")
    n = ask_int("Choose instructor: ", 1, len(ids))
    return ids[n - 1]


# ----------------------------------------------------------------------
# ANALYZE MODE
# ----------------------------------------------------------------------
STATUS_TAG = {
    "OK": "Eligible",
    "CONFIRM": "Eligible - prerequisites to confirm",
    "NO": "NOT eligible",
    "DONE": "Completed",
}

FOOTNOTE = "  * = code and/or credits not confirmed in the HU catalog pages - check PSCS."


def list_available():
    avail = available_courses()
    print(f"\n=== HU COURSES AVAILABLE IN SEMESTER {student['sem']} ===")
    if not avail:
        print("No courses are offered in this semester.")
        return
    flagged = False
    for cid in avail:
        status, notes, missing = eligibility(cid)
        c = COURSES[cid]
        if c["verify"]:
            flagged = True
        flag = "  [IN CART]" if cid in cart else ""
        print(f"{course_label(cid)} | {c['credits']} cr | {STATUS_TAG[status]}{flag}")
        for n in notes:
            print(f"      - {n}")
        for r in missing:
            print(f"      - needs {req_text(r)}")
    if flagged:
        print(FOOTNOTE)


def course_info():
    cid = ask_course("Course code (e.g. BIO 101): ")
    if cid is None:
        return
    c = COURSES[cid]
    print(f"\n=== {course_label(cid)} ===")
    print(f"Credits : {c['credits']}")
    print(f"Offered : semesters {', '.join(str(s) for s in c['sems'])}")
    print("Timings :")
    for (d, s, e, kind) in c["lectures"]:
        print(f"    {d} {fmt(s)} - {fmt(e)}  [{kind}]")
    rules = rules_text(cid)
    print("Rules   :" + (" none" if not rules else ""))
    for r in rules:
        print(f"    - {r}")
    if c["requires"]:
        print("Prerequisite chain:")
        show_chain(cid)
    if c["verify"]:
        print(f"Check   : {c['verify']} not confirmed in the HU catalog - verify on PSCS.")
    print()
    fetchInstructorInfo(c["instructor"])


def instructor_info():
    iid = pick_instructor()
    print()
    fetchInstructorInfo(iid)


def rate_instructor():
    iid = pick_instructor()
    r = ask_int("Your rating (1-5): ", 1, 5)
    INSTRUCTORS[iid]["ratings"].append(r)
    print(f"Thanks! {INSTRUCTORS[iid]['name']} is now: {rating_text(INSTRUCTORS[iid])}")


def get_recommendations():
    """Returns (projected, remaining, picks, maybe).
    picks: list of (course, [reasons]); maybe: list of (course, [missing requirements])."""
    projected = student["current"] + cart_credits()
    remaining = MAX_CREDITS - projected
    raw = []
    maybe = []
    if remaining > 0:
        for cid in available_courses():
            if cid in cart:
                continue
            status, notes, missing = eligibility(cid)
            if status in ("NO", "DONE"):
                continue
            if COURSES[cid]["credits"] > remaining:
                continue
            clash_with = [o for o in cart if clashes(cid, o)]
            if clash_with:
                continue
            unlocks = 0
            for other in COURSES:
                for r in COURSES[other]["requires"]:
                    if cid in r["courses"]:
                        unlocks += 1
            score = unlocks * 2 + (3 if projected < MIN_CREDITS else 0)
            if status == "OK":
                raw.append((score, cid, unlocks))
            else:
                maybe.append((cid, missing))
    raw.sort(key=lambda p: (-p[0], p[1]))
    picks = []
    for (score, cid, unlocks) in raw[:5]:
        why = []
        if unlocks:
            why.append(f"unlocks {unlocks} later course(s)")
        if projected < MIN_CREDITS:
            why.append("helps you reach the 12-credit minimum")
        why.append("no clash with your cart")
        picks.append((cid, why))
    return projected, remaining, picks, maybe[:3]


def recommend():
    projected, remaining, picks, maybe = get_recommendations()
    print("\n=== RECOMMENDATIONS ===")
    print(f"Projected credits: {projected} | Remaining capacity: {max(remaining, 0)}")
    if remaining <= 0:
        print("You've reached the HU maximum credit load - no more courses recommended.")
        return
    if not picks:
        print("No fully eligible, clash-free courses fit right now.")
    for (cid, why) in picks:
        print(f"  * {course_label(cid)} - " + "; ".join(why))
    if maybe:
        print("\nPossible if you've completed the listed prerequisites:")
        for (cid, missing) in maybe:
            names = "; ".join(req_text(r) for r in missing)
            print(f"  ~ {course_label(cid)} (confirm: {names})")


def analyze_mode():
    while True:
        print("\n=== ANALYZE MODE ===")
        print(" 1. Available courses + eligibility")
        print(" 2. Course info (details, prerequisites, instructor)")
        print(" 3. Instructor info (office hours, rating, TAs)")
        print(" 4. Weekly calendar + conflict check")
        print(" 5. Recommendations")
        print(" 6. Credit summary (overload / underload)")
        print(" 7. Rate an instructor")
        print(" 0. Back")
        ch = ask_int("Choose: ", 0, 7)
        if ch == 0:
            return
        elif ch == 1:
            list_available()
        elif ch == 2:
            course_info()
        elif ch == 3:
            instructor_info()
        elif ch == 4:
            show_calendar()
        elif ch == 5:
            recommend()
        elif ch == 6:
            credit_report()
        elif ch == 7:
            rate_instructor()


# ----------------------------------------------------------------------
# ENROLL MODE
# ----------------------------------------------------------------------
def add_course():
    cid = ask_course("Course code to ADD (e.g. MATH 101): ")
    if cid is None:
        return
    if cid not in available_courses():
        print(f"  {cid} is not offered in semester {student['sem']}.")
        return
    if cid in cart:
        print(f"  {cid} is already in your cart.")
        return

    status, notes, missing = eligibility(cid)
    if status in ("NO", "DONE"):
        print(f"  Cannot add {cid}: {notes[0]}.")
        return
    if status == "CONFIRM":
        for r in missing:
            print(f"  Prerequisite needed: {req_text(r)}")
            ok = False
            for c in r["courses"]:
                if c in cart:
                    print(f"  {c} is only in your cart (pending), so it doesn't count as completed.")
                    continue
                if ask_yes_no(f"  Have you completed {course_label(c)}? (y/n): "):
                    mark_completed(c)
                    ok = True
                    break
            if not ok:
                print(f"  Cannot add {cid} - prerequisite not met. Path to get there:")
                show_chain(cid)
                return

    found = []
    for other in cart:
        for (d, s, e) in clashes(cid, other):
            found.append((other, d, s, e))
    if found:
        print(f"  WARNING: {cid} clashes with courses in your cart:")
        for (other, d, s, e) in found:
            print(f"    ! {other} on {d}, {fmt(s)} - {fmt(e)}")
        if not ask_yes_no("  Add it anyway? (y/n): "):
            print("  Not added.")
            return

    cart.append(cid)
    print(f"  Added {course_label(cid)} to your cart.")
    credit_report()


def drop_course():
    cid = ask_course("Course code to DROP: ")
    if cid is None:
        return
    if cid in cart:
        cart.remove(cid)
        print(f"  Dropped {course_label(cid)} from your cart.")
        credit_report()
    else:
        print(f"  {cid} is not in your cart, so there is nothing to drop.")


def view_cart():
    print("\n=== YOUR CART (pending changes) ===")
    if not cart:
        print("Cart is empty.")
    for cid in cart:
        print(f"  {course_label(cid)} | {COURSES[cid]['credits']} cr")
    credit_report()


def enroll_mode():
    while True:
        print("\n=== ENROLL MODE (Add / Drop) ===")
        print(" 1. Add a course")
        print(" 2. Drop a course")
        print(" 3. View cart")
        print(" 4. Weekly calendar + conflicts")
        print(" 5. Show available courses")
        print(" 0. Back")
        ch = ask_int("Choose: ", 0, 5)
        if ch == 0:
            return
        elif ch == 1:
            add_course()
        elif ch == 2:
            drop_course()
        elif ch == 3:
            view_cart()
        elif ch == 4:
            show_calendar()
        elif ch == 5:
            list_available()


# ----------------------------------------------------------------------
# START
# ----------------------------------------------------------------------
def setup():
    print("=" * 60)
    print("  Habib University | EaseEnroll")
    print("  Simplified Enrollment System - saves you chaos later on.")
    print("=" * 60)
    student["sem"] = ask_int("Semester number you want to enroll in (1-8): ", 1, 8)
    student["current"] = ask_int("Your current credit hours: ", 0, 30)
    print("\nWhich subjects did you study in HSSC?")
    for i, s in enumerate(HSSC_SUBJECTS, 1):
        print(f"  {i}. {s}")
    raw = input("Numbers separated by commas (or press Enter for none): ")
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit() and 1 <= int(part) <= len(HSSC_SUBJECTS):
            subj = HSSC_SUBJECTS[int(part) - 1]
            if subj not in student["hssc"]:
                student["hssc"].append(subj)
    shown = ", ".join(student["hssc"]) if student["hssc"] else "none"
    print(f"HSSC subjects recorded: {shown}")


def main():
    setup()
    list_available()
    while True:
        print("\n=== MODE SELECTION ===")
        print(" 1. Analyze Mode")
        print(" 2. Enroll Mode (Add / Drop)")
        print(" 3. Quit")
        ch = ask_int("Choose: ", 1, 3)
        if ch == 1:
            analyze_mode()
        elif ch == 2:
            enroll_mode()
        else:
            break
    print("\nFinal cart - a PLAN only. Complete your actual enrollment in PSCS")
    print("during your enrollment window.")
    view_cart()
    print("\nGoodbye!")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nExited.")
