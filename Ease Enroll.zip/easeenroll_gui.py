"""
EaseEnroll GUI - Habib University edition
Point-and-click front end for easeenroll.py.

HOW IT IS LINKED
  This file does `import easeenroll as ee` and uses the SAME data and logic
  (COURSES, INSTRUCTORS, eligibility(), clashes(), the cart, credit rules,
  the recursive fetchInstructorInfo(), ...). Nothing is duplicated:
  change a course or a rule in easeenroll.py and both the terminal app and
  this GUI pick it up.

RUN
  Keep easeenroll.py and easeenroll_gui.py in the SAME folder, then:
      python easeenroll_gui.py

NOTE ON LIBRARIES
  The core (easeenroll.py) has no imports at all. A window needs a toolkit,
  and Python's only built-in one is tkinter, so this GUI file uses it
  (it ships with Python - nothing to pip install).
"""

import tkinter as tk
from tkinter import ttk, messagebox

import easeenroll as ee

PALETTE = ["#cfe8ff", "#d8f3dc", "#ffe8b3", "#e9d5ff", "#ffd6e0", "#d0f0f0", "#fde2c8", "#e3e8b8"]
LEVEL_COLOR = {"ok": "#1b5e20", "under": "#e65100", "over": "#b71c1c"}


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Habib University | EaseEnroll")
        self.root.geometry("1180x720")
        self.root.minsize(980, 600)
        try:
            ttk.Style().theme_use("clam")
        except tk.TclError:
            pass
        self.mode = tk.StringVar(value="analyze")
        self.colors = {}
        self.rec_ids = []
        self.container = ttk.Frame(self.root, padding=10)
        self.container.pack(fill="both", expand=True)
        self.show_setup()

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    def clear(self):
        for w in self.container.winfo_children():
            w.destroy()

    @staticmethod
    def set_text(widget, text):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.config(state="disabled")

    def selected(self):
        sel = self.tree.selection()
        return sel[0] if sel else None

    def color_for(self, cid):
        if cid not in self.colors:
            self.colors[cid] = PALETTE[len(self.colors) % len(PALETTE)]
        return self.colors[cid]

    # ------------------------------------------------------------------
    # SETUP SCREEN (semester, current credits, HSSC subjects)
    # ------------------------------------------------------------------
    def show_setup(self):
        self.clear()
        ee.cart.clear()
        ee.student["completed"].clear()
        ee.student["hssc"] = []
        f = ttk.Frame(self.container)
        f.place(relx=0.5, rely=0.45, anchor="center")
        ttk.Label(f, text="Habib University | EaseEnroll",
                  font=("Helvetica", 20, "bold")).grid(row=0, column=0, columnspan=2)
        ttk.Label(f, text="Simplified Enrollment System - saves you chaos later on.").grid(
            row=1, column=0, columnspan=2, pady=(0, 16))

        ttk.Label(f, text="Semester you want to enroll in:").grid(row=2, column=0, sticky="e", padx=6, pady=6)
        self.sem_var = tk.StringVar(value="1")
        ttk.Combobox(f, textvariable=self.sem_var, values=[str(i) for i in range(1, 9)],
                     state="readonly", width=6).grid(row=2, column=1, sticky="w")

        ttk.Label(f, text="Your current credit hours:").grid(row=3, column=0, sticky="e", padx=6, pady=6)
        self.cred_var = tk.StringVar(value="0")
        ttk.Spinbox(f, from_=0, to=30, textvariable=self.cred_var, width=6).grid(row=3, column=1, sticky="w")

        ttk.Label(f, text="Subjects you studied in HSSC:").grid(row=4, column=0, sticky="ne", padx=6, pady=6)
        box = ttk.Frame(f)
        box.grid(row=4, column=1, sticky="w")
        self.hssc_vars = {}
        for subj in ee.HSSC_SUBJECTS:
            v = tk.BooleanVar(value=False)
            ttk.Checkbutton(box, text=subj, variable=v).pack(anchor="w")
            self.hssc_vars[subj] = v

        ttk.Button(f, text="Start", command=self.start).grid(row=5, column=0, columnspan=2, pady=18)

    def start(self):
        text = self.cred_var.get().strip()
        if not (text.isdigit() and 0 <= int(text) <= 30):
            messagebox.showerror("Credit hours", "Please enter your current credit hours (0-30).")
            return
        ee.student["sem"] = int(self.sem_var.get())
        ee.student["current"] = int(text)
        ee.student["hssc"] = [s for s, v in self.hssc_vars.items() if v.get()]
        ee.student["completed"].clear()
        ee.cart.clear()
        self.build_main()

    # ------------------------------------------------------------------
    # MAIN WINDOW
    # ------------------------------------------------------------------
    def build_main(self):
        self.clear()
        self.colors = {}
        top = ttk.Frame(self.container)
        top.pack(fill="x")
        ttk.Label(top, text="Habib University | EaseEnroll", font=("Helvetica", 14, "bold")).pack(side="left")
        hs = ", ".join(ee.student["hssc"]) or "none"
        ttk.Label(top, text=f"     Semester {ee.student['sem']}   |   HSSC: {hs}").pack(side="left")
        ttk.Button(top, text="New session", command=self.show_setup).pack(side="right")
        modes = ttk.Frame(top)
        modes.pack(side="right", padx=18)
        ttk.Radiobutton(modes, text="Analyze Mode", variable=self.mode, value="analyze",
                        command=self.apply_mode).pack(side="left", padx=6)
        ttk.Radiobutton(modes, text="Enroll Mode (Add / Drop)", variable=self.mode, value="enroll",
                        command=self.apply_mode).pack(side="left", padx=6)

        self.nb = ttk.Notebook(self.container)
        self.nb.pack(fill="both", expand=True, pady=(8, 0))
        self.build_courses_tab()
        self.build_calendar_tab()
        self.build_rec_tab()
        self.build_instr_tab()
        self.apply_mode()
        self.refresh()

    def apply_mode(self):
        state = "normal" if self.mode.get() == "enroll" else "disabled"
        for b in (self.add_btn, self.drop_btn, self.rec_add_btn):
            b.config(state=state)
        self.mode_hint.config(
            text="Enroll Mode: use Add / Drop (or double-click a course to add)."
            if state == "normal" else "Analyze Mode: browse only. Switch to Enroll Mode to change your cart.")

    def need_enroll_mode(self):
        if self.mode.get() != "enroll":
            messagebox.showinfo("Analyze Mode", "Switch to Enroll Mode (top right) to add or drop courses.")
            return True
        return False

    # ---------------------------- courses & cart tab -------------------
    def build_courses_tab(self):
        tab = ttk.Frame(self.nb, padding=8)
        self.nb.add(tab, text="Courses & Cart")
        tab.columnconfigure(0, weight=3)
        tab.columnconfigure(1, weight=2)
        tab.rowconfigure(0, weight=1)

        left = ttk.Frame(tab)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)
        ttk.Label(left, text=f"Courses offered in semester {ee.student['sem']} - click one",
                  font=("Helvetica", 11, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 4))
        self.tree = ttk.Treeview(left, columns=("code", "name", "cr", "status"),
                                 show="headings", selectmode="browse")
        for col, title, width in (("code", "Code", 90), ("name", "Course", 260),
                                  ("cr", "Cr", 40), ("status", "Status", 230)):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor="w")
        self.tree.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(left, command=self.tree.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.tag_configure("ok", foreground="#1b5e20")
        self.tree.tag_configure("confirm", foreground="#8a5a00")
        self.tree.tag_configure("no", foreground="#9e9e9e")
        self.tree.tag_configure("done", foreground="#1565c0")
        self.tree.tag_configure("incart", background="#e3f2fd")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.show_details())
        self.tree.bind("<Double-1>", self.on_tree_double)
        ttk.Label(left, text="* = code and/or credits not confirmed in the HU catalog - check PSCS.",
                  foreground="#666666").grid(row=2, column=0, sticky="w", pady=(4, 0))

        right = ttk.Frame(tab)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=3)
        right.rowconfigure(3, weight=1)
        self.detail = tk.Text(right, wrap="word", height=14, state="disabled",
                              font="TkFixedFont", background="#fafafa")
        self.detail.grid(row=0, column=0, sticky="nsew")

        btns = ttk.Frame(right)
        btns.grid(row=1, column=0, sticky="ew", pady=6)
        self.add_btn = ttk.Button(btns, text="Add to cart", command=self.add_selected)
        self.add_btn.pack(side="left", padx=(0, 6))
        self.drop_btn = ttk.Button(btns, text="Drop from cart", command=self.drop_selected)
        self.drop_btn.pack(side="left")
        self.mode_hint = ttk.Label(btns, text="", foreground="#666666")
        self.mode_hint.pack(side="left", padx=10)

        ttk.Label(right, text="Your cart (pending changes)",
                  font=("Helvetica", 11, "bold")).grid(row=2, column=0, sticky="w")
        self.cart_list = tk.Listbox(right, height=5, exportselection=False)
        self.cart_list.grid(row=3, column=0, sticky="nsew")
        self.cart_list.bind("<<ListboxSelect>>", self.on_cart_select)
        self.credit_lbl = tk.Label(right, justify="left", anchor="w", wraplength=420)
        self.credit_lbl.grid(row=4, column=0, sticky="ew", pady=(6, 0))
        self.conflict_lbl = tk.Label(right, justify="left", anchor="w", wraplength=420)
        self.conflict_lbl.grid(row=5, column=0, sticky="ew")

    def on_tree_double(self, event):
        if self.tree.identify_row(event.y):   # only when a course row was double-clicked
            self.add_selected()

    def on_cart_select(self, event=None):
        sel = self.cart_list.curselection()
        if sel:
            cid = ee.cart[sel[0]]
            self.tree.selection_set((cid,))
            self.tree.see(cid)

    def show_details(self):
        cid = self.selected()
        if not cid:
            return
        c = ee.COURSES[cid]
        lines = [ee.course_label(cid),
                 f"Credits: {c['credits']}    Offered: semesters {', '.join(str(s) for s in c['sems'])}",
                 "", "Timings:"]
        for (d, s, e, kind) in c["lectures"]:
            lines.append(f"  {d[:3]} {ee.fmt(s)} - {ee.fmt(e)}  [{kind}]")
        status, notes, missing = ee.eligibility(cid)
        lines += ["", "Status: " + ee.STATUS_TAG[status]]
        for n in notes:
            lines.append("  - " + n)
        for r in missing:
            lines.append("  - needs " + ee.req_text(r))
        rules = ee.rules_text(cid)
        lines += ["", "Rules:" + (" none" if not rules else "")]
        for r in rules:
            lines.append("  - " + r)
        if c["requires"]:
            lines += ["", "Prerequisite chain:"]
            ee.show_chain(cid, out=lines)           # recursive, from easeenroll.py
        if c["verify"]:
            lines += ["", f"Check: {c['verify']} not confirmed in the HU catalog - verify on PSCS."]
        lines.append("")
        ee.fetchInstructorInfo(c["instructor"], out=lines)   # recursive (TAs), from easeenroll.py
        self.set_text(self.detail, "\n".join(lines))

    # ---------------------------- add / drop ---------------------------
    def add_selected(self):
        cid = self.selected()
        if not cid:
            messagebox.showinfo("Add course", "Click a course first.")
            return
        self.add_course(cid)

    def add_course(self, cid):
        if self.need_enroll_mode():
            return
        if cid in ee.cart:
            messagebox.showinfo("Add course", f"{cid} is already in your cart.")
            return
        status, notes, missing = ee.eligibility(cid)
        if status in ("NO", "DONE"):
            messagebox.showwarning("Cannot add", f"Cannot add {cid}:\n{notes[0]}.")
            return
        if status == "CONFIRM":
            for r in missing:
                ok = False
                for c in r["courses"]:
                    if c in ee.cart:
                        continue  # pending courses don't count as completed
                    answer = messagebox.askyesno(
                        "Prerequisite check",
                        f"{cid} needs: {ee.req_text(r)}\n\nHave you completed {ee.course_label(c)}?")
                    if answer:
                        ee.mark_completed(c)
                        ok = True
                        break
                if not ok:
                    chain = []
                    ee.show_chain(cid, out=chain)
                    messagebox.showwarning(
                        "Prerequisite not met",
                        f"Cannot add {cid} - prerequisite not met.\n\nPath to get there:\n" + "\n".join(chain))
                    self.refresh()
                    return
        found = []
        for other in ee.cart:
            for (d, s, e) in ee.clashes(cid, other):
                found.append(f"{other} on {d}, {ee.fmt(s)} - {ee.fmt(e)}")
        if found:
            if not messagebox.askyesno("Timing clash",
                                       f"{cid} clashes with your cart:\n\n" + "\n".join(found) +
                                       "\n\nAdd it anyway?"):
                self.refresh()
                return
        ee.cart.append(cid)
        self.refresh()
        added, projected, level, msgs = ee.credit_status()
        if level != "ok":
            messagebox.showwarning("Credit load", "\n".join(msgs))

    def drop_selected(self):
        if self.need_enroll_mode():
            return
        cid = self.selected()
        if not cid:
            messagebox.showinfo("Drop course", "Click a course first.")
            return
        if cid in ee.cart:
            ee.cart.remove(cid)
            self.refresh()
        else:
            messagebox.showinfo("Drop course", f"{cid} is not in your cart, so there is nothing to drop.")

    # ---------------------------- calendar tab -------------------------
    def build_calendar_tab(self):
        tab = ttk.Frame(self.nb, padding=8)
        self.nb.add(tab, text="Weekly Calendar")
        tab.rowconfigure(0, weight=1)
        tab.columnconfigure(0, weight=1)
        self.cal = tk.Canvas(tab, background="white", highlightthickness=1, highlightbackground="#cccccc")
        self.cal.grid(row=0, column=0, sticky="nsew")
        vs = ttk.Scrollbar(tab, orient="vertical", command=self.cal.yview)
        vs.grid(row=0, column=1, sticky="ns")
        self.cal.configure(yscrollcommand=vs.set)
        self.cal_legend = tk.Label(tab, justify="left", anchor="w", wraplength=1000)
        self.cal_legend.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(6, 0))

    def refresh_calendar(self):
        cv = self.cal
        cv.delete("all")
        if not ee.cart:
            cv.create_text(20, 20, anchor="nw", font=("Helvetica", 12),
                           text="Your cart is empty - add courses in Enroll Mode to see your week.")
            self.cal_legend.config(text="")
            return
        lo = 24 * 60
        hi = 0
        for cid in ee.cart:
            for (d, s, e, k) in ee.COURSES[cid]["lectures"]:
                lo = min(lo, s)
                hi = max(hi, e)
        lo = lo // 30 * 30
        hi = (hi + 29) // 30 * 30
        left, top, colw, rowh = 80, 32, 150, 28
        rows = (hi - lo) // 30
        cv.configure(scrollregion=(0, 0, left + colw * 5 + 10, top + rows * rowh + 10))
        for i, day in enumerate(ee.DAYS):
            cv.create_text(left + i * colw + colw / 2, top / 2, text=day, font=("Helvetica", 10, "bold"))
        for i in range(rows + 1):
            y = top + i * rowh
            cv.create_line(left, y, left + colw * 5, y, fill="#e0e0e0")
            if i < rows:
                cv.create_text(left - 8, y + 2, anchor="ne", text=ee.fmt(lo + i * 30), fill="#555555")
        for i in range(6):
            x = left + i * colw
            cv.create_line(x, top, x, top + rows * rowh, fill="#cccccc")

        for di, day in enumerate(ee.DAYS):
            slots = []
            for cid in ee.cart:
                for (d, s, e, k) in ee.COURSES[cid]["lectures"]:
                    if d == day:
                        slots.append((s, e, cid, k))
            slots.sort()
            placed = []
            for (s, e, cid, k) in slots:
                clash = any(o[2] != cid and s < o[1] and o[0] < e for o in slots)
                used = [p[3] for p in placed if s < p[1] and p[0] < e]
                col = 1 if 0 in used else 0
                placed.append((s, e, cid, col))
                width = colw / 2 if clash else colw
                x0 = left + di * colw + (col * width if clash else 0) + 2
                x1 = x0 + width - 4
                y0 = top + (s - lo) / 30 * rowh + 1
                y1 = top + (e - lo) / 30 * rowh - 1
                cv.create_rectangle(x0, y0, x1, y1,
                                    fill="#ffb3b3" if clash else self.color_for(cid),
                                    outline="#c62828" if clash else "#777777")
                cv.create_text((x0 + x1) / 2, (y0 + y1) / 2, text=f"{cid}\n{k}",
                               font=("Helvetica", 8), width=width - 8, justify="center")
        conflicts = ee.all_conflicts()
        if conflicts:
            text = "CONFLICTS (shown in red):  " + "   |   ".join(
                f"{a} & {b}: {d[:3]} {ee.fmt(s)}-{ee.fmt(e)}" for (a, b, d, s, e) in conflicts)
            self.cal_legend.config(text=text, fg="#b71c1c")
        else:
            self.cal_legend.config(text="No timing conflicts in your cart.", fg="#1b5e20")

    # ---------------------------- recommendations tab ------------------
    def build_rec_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Recommendations")
        ttk.Label(tab, text="Suggested courses (eligibility + schedule + remaining credit capacity)",
                  font=("Helvetica", 11, "bold")).pack(anchor="w")
        self.rec_info = ttk.Label(tab, text="")
        self.rec_info.pack(anchor="w", pady=(2, 6))
        self.rec_list = tk.Listbox(tab, height=8, exportselection=False)
        self.rec_list.pack(fill="x")
        self.rec_add_btn = ttk.Button(tab, text="Add selected recommendation to cart",
                                      command=self.add_recommended)
        self.rec_add_btn.pack(anchor="w", pady=8)
        ttk.Label(tab, text="Possible if you've completed the listed prerequisites:").pack(anchor="w")
        self.rec_maybe = tk.Text(tab, height=6, wrap="word", state="disabled", background="#fafafa")
        self.rec_maybe.pack(fill="x")

    def refresh_recs(self):
        projected, remaining, picks, maybe = ee.get_recommendations()
        self.rec_list.delete(0, "end")
        self.rec_ids = [cid for cid, why in picks]
        info = f"Projected credits: {projected}   |   Remaining capacity: {max(remaining, 0)}"
        if remaining <= 0:
            info += "   -   HU maximum reached, no more courses recommended."
        elif not picks:
            info += "   -   No fully eligible, clash-free courses fit right now."
        self.rec_info.config(text=info)
        for cid, why in picks:
            self.rec_list.insert("end", f"{ee.course_label(cid)}   -   " + "; ".join(why))
        lines = [f"{ee.course_label(cid)}  (confirm: " + "; ".join(ee.req_text(r) for r in missing) + ")"
                 for cid, missing in maybe]
        self.set_text(self.rec_maybe, "\n".join(lines) if lines else "None right now.")

    def add_recommended(self):
        sel = self.rec_list.curselection()
        if not sel:
            messagebox.showinfo("Recommendations", "Click a recommendation first.")
            return
        self.add_course(self.rec_ids[sel[0]])

    # ---------------------------- instructors tab ----------------------
    def build_instr_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="Instructors")
        tab.columnconfigure(1, weight=1)
        tab.rowconfigure(0, weight=1)
        self.instr_ids = [k for k in ee.INSTRUCTORS if k != "tba"]
        self.instr_list = tk.Listbox(tab, width=26, exportselection=False)
        for k in self.instr_ids:
            self.instr_list.insert("end", ee.INSTRUCTORS[k]["name"])
        self.instr_list.grid(row=0, column=0, sticky="ns", padx=(0, 10))
        self.instr_list.bind("<<ListboxSelect>>", lambda e: self.show_instructor())
        self.instr_text = tk.Text(tab, wrap="word", state="disabled", font="TkFixedFont", background="#fafafa")
        self.instr_text.grid(row=0, column=1, sticky="nsew")
        rate = ttk.Frame(tab)
        rate.grid(row=1, column=1, sticky="w", pady=8)
        ttk.Label(rate, text="Rate this instructor:").pack(side="left", padx=(0, 8))
        for n in range(1, 6):
            ttk.Button(rate, text=str(n), width=3, command=lambda n=n: self.rate_instructor(n)).pack(side="left", padx=2)

    def current_instructor(self):
        sel = self.instr_list.curselection()
        return self.instr_ids[sel[0]] if sel else None

    def show_instructor(self):
        iid = self.current_instructor()
        if not iid:
            return
        lines = []
        ee.fetchInstructorInfo(iid, out=lines)
        self.set_text(self.instr_text, "\n".join(lines))

    def rate_instructor(self, n):
        iid = self.current_instructor()
        if not iid:
            messagebox.showinfo("Rate instructor", "Click an instructor first.")
            return
        ee.INSTRUCTORS[iid]["ratings"].append(n)
        self.show_instructor()

    # ------------------------------------------------------------------
    # REFRESH (everything is recomputed from the cart -> always consistent)
    # ------------------------------------------------------------------
    def refresh(self):
        keep = self.selected()
        self.tree.delete(*self.tree.get_children())
        for cid in ee.available_courses():
            status, notes, missing = ee.eligibility(cid)
            c = ee.COURSES[cid]
            tag = {"OK": "ok", "CONFIRM": "confirm", "NO": "no", "DONE": "done"}[status]
            label = ee.STATUS_TAG[status] + ("  [IN CART]" if cid in ee.cart else "")
            tags = (tag, "incart") if cid in ee.cart else (tag,)
            self.tree.insert("", "end", iid=cid, tags=tags,
                             values=(cid + ("*" if c["verify"] else ""), c["name"], c["credits"], label))
        if keep and self.tree.exists(keep):
            self.tree.selection_set((keep,))
        self.show_details()

        self.cart_list.delete(0, "end")
        for cid in ee.cart:
            self.cart_list.insert("end", f"{ee.course_label(cid)}  |  {ee.COURSES[cid]['credits']} cr")
        added, projected, level, msgs = ee.credit_status()
        self.credit_lbl.config(
            fg=LEVEL_COLOR[level],
            text=f"Current {ee.student['current']} + cart {added} = projected {projected} "
                 f"(HU allows {ee.MIN_CREDITS}-{ee.MAX_CREDITS})\n" + "\n".join(msgs))
        conflicts = ee.all_conflicts()
        if conflicts:
            self.conflict_lbl.config(fg="#b71c1c", text="Conflicts:\n" + "\n".join(
                f"! {a} & {b}: {d[:3]} {ee.fmt(s)} - {ee.fmt(e)}" for (a, b, d, s, e) in conflicts))
        else:
            self.conflict_lbl.config(fg="#1b5e20", text="No timing conflicts in your cart.")

        self.refresh_calendar()
        self.refresh_recs()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    App().run()
