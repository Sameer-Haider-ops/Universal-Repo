import machine

_PADS_BANK0_BASE = 0x40038000
_DRIVE_LSB = 4
_DRIVE_MASK = 0x3 << _DRIVE_LSB   # bits [5:4]

_DRIVE_LEVELS = {2: 0b00, 4: 0b01, 8: 0b10, 12: 0b11}  # mA -> register value

def set_drive_strength(gpio, level_ma):
    """
    Set the output drive strength of a GPIO pad on the Pico 2 W (RP2350).

    gpio:     GPIO number (0-47 on RP2350's GPIO bank)
    level_ma: one of 2, 4, 8, 12 (milliamps)

    This pokes the PADS_BANK0 control register directly, because
    MicroPython's rp2 port does not expose a drive= option for this chip.
    Call it AFTER you've set the pin's mode with machine.Pin(), e.g.:

        led = machine.Pin(15, machine.Pin.OUT)
        set_drive_strength(15, 12)
        led.value(1)

    Setting a higher drive strength does not change how MUCH current your
    circuit draws — that's still set by your resistor. It only raises the
    ceiling before the pin's output voltage sags under load. Confirm with
    a DMM that you're seeing the current you expect before relying on this.
    """
    if level_ma not in _DRIVE_LEVELS:
        raise ValueError("level_ma must be 2, 4, 8, or 12")
    if not (0 <= gpio <= 47):
        raise ValueError("gpio out of range for RP2350")

    reg_addr = _PADS_BANK0_BASE + 4 * (gpio + 1)  # +1: voltage_select occupies offset 0
    current = machine.mem32[reg_addr]
    updated = (current & ~_DRIVE_MASK) | (_DRIVE_LEVELS[level_ma] << _DRIVE_LSB)
    machine.mem32[reg_addr] = updated