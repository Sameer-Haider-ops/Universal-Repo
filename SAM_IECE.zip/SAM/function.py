from machine import Pin ,PWM
from utime import sleep
button_pin = 16
led_pin = 17
dimmer_pin = 21
heart = Pin("LED", Pin.OUT)
brighter = Pin(button_pin , Pin.IN , Pin.PULL_UP)
dimmer = Pin(dimmer_pin , Pin.IN, Pin.PULL_UP)
def set_brightness(duty_cycle):
    led_pwm = PWM(Pin(led_pin))
    led_pwm.freq(1000)
    led_pwm.duty_u16(duty_cycle)

presses =0
led_on = False


#-> FUNCTIONS
def on_press(pin):
    global presses, led_on
    led_on = not led_on
    if led_on:
        set_brightness(65535)
    else:
        set_brightness(0)
    presses = presses + 1
    print(presses)
# runs the moment the pin falls
# explained after this task
#-> LOOP: attach the handler once, just above while True:
brighter.irq(trigger=Pin.IRQ_FALLING, handler=on_press)
while True:
    heart.toggle()
    sleep(0.5)
    print(dimmer.value())
    sleep(0.2)
    # the loop now only beats