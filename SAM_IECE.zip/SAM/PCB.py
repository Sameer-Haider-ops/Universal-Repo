# pcb_test.py -- steps the brightness; not part of main.py
# -> IMPORTS
from machine import Pin, PWM
from time import sleep
# -> CONSTANTS
LED_PIN = 15 # YOUR pin: the one that drives your breadboard LED
PWM_FREQ = 1000 # YOUR PWM frequency
HOLD_S = 5 
i = 1# long enough to read the DMM
# -> SETUP
led = PWM(Pin(LED_PIN))
led.freq(PWM_FREQ)
# -> FUNCTIONS
def set_brightness(level): # level is a percentage, as in main.py
    led.duty_u16(int(level * 65535 / 100))
def hold(level):
    set_brightness(level)
    print(level)
    sleep(HOLD_S)
# -> LOOP (runs once)

hold(0)
hold(25)
hold(50)
hold(75)
hold(100)
while(1):
    set_brightness(50)
