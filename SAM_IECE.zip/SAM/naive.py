# naive.py -- one loop that does everything. Given to you for Session 17.
# You measure this program; you do not fix it. Replace every line marked YOUR.
# Standard layout, five sections, in order.

# ---- 1  IMPORTS ------------------------------------------------------
from machine import ADC, Pin, PWM
from time import sleep_ms, ticks_ms, ticks_diff

# ---- 2  CONSTANTS ----------------------------------------------------
LED_PIN        = 17     # YOUR LED's GPIO number, from your main.py
BRIGHTER_PIN   = 16     # YOUR brighter button's GPIO number, from your main.py
DIMMER_PIN     = 21     # YOUR dimmer button's GPIO number, from your main.py
LDR_PIN        = 27     # GP27, physical pin 32
PWM_FREQ       = 1000   # YOUR LED's PWM frequency, in Hz
LEVELS         = [0, 5, 15, 40, 100]   # YOUR levels from Session 11
DARK           = 3000   # YOUR covered count from Session 12
BRIGHT         = 60000  # YOUR flashlight count from Session 12
DEBOUNCE_MS    = 20     # wait after a press, so the bounce has passed
HEARTBEAT_MS   = 500    # how often the heartbeat should flip
LDR_EVERY_MS   = 600    # how long after one LDR reading the next is due
N_AVERAGE      = 10     # readings averaged into one LDR reading
AVERAGE_GAP_MS = 30     # pause between those readings
LOOP_MS        = 10     # pause at the end of every trip round the loop

# ---- 3  SETUP --------------------------------------------------------
led      = PWM(Pin(LED_PIN))
led.freq(PWM_FREQ)
brighter = Pin(BRIGHTER_PIN, Pin.IN, Pin.PULL_UP)
dimmer   = Pin(DIMMER_PIN, Pin.IN, Pin.PULL_UP)
ldr      = ADC(Pin(LDR_PIN))
heart    = Pin("LED", Pin.OUT)       # the on-board LED

level_index       = 0                # which of LEVELS the buttons chose
taps              = 0                # button presses this program has seen
brighter_was_down = False
dimmer_was_down   = False
last_beat         = ticks_ms()       # when the heartbeat last flipped
last_read         = ticks_ms()       # when the LDR was last read

# ---- 4  FUNCTIONS ----------------------------------------------------
def set_brightness(level):           # 0 to 100, the same job as yours
    led.duty_u16(int(level * 65535 / 100))

def light_percent(counts):           # 0 at DARK, 100 at BRIGHT, clamped
    if counts <= DARK:
        return 0
    if counts >= BRIGHT:
        return 100
    return (counts - DARK) * 100 / (BRIGHT - DARK)

def read_average():                  # the mean of N_AVERAGE readings
    total = 0
    for i in range(N_AVERAGE):
        total = total + ldr.read_u16()
        sleep_ms(AVERAGE_GAP_MS)
    return total / N_AVERAGE

def step(direction):                 # one level up (+1) or down (-1)
    global level_index, taps
    level_index = level_index + direction
    if level_index < 0:
        level_index = 0
    if level_index > len(LEVELS) - 1:
        level_index = len(LEVELS) - 1
    taps = taps + 1
    set_brightness(LEVELS[level_index])
    print("button:", LEVELS[level_index], "   taps seen:", taps)
    sleep_ms(DEBOUNCE_MS)

def look_at_buttons():               # one look at each button, per trip
    global brighter_was_down, dimmer_was_down
    down = brighter.value() == 0
    if down and not brighter_was_down:
        step(+1)
    brighter_was_down = down
    down = dimmer.value() == 0
    if down and not dimmer_was_down:
        step(-1)
    dimmer_was_down = down

def beat_if_due():                   # flip the heartbeat if it is time
    global last_beat
    now = ticks_ms()
    if ticks_diff(now, last_beat) >= HEARTBEAT_MS:
        heart.toggle()
        print("heartbeat period:", ticks_diff(now, last_beat), "ms")
        last_beat = now

def read_light_if_due():             # read the LDR and set the LED, if due
    global last_read
    if ticks_diff(ticks_ms(), last_read) >= LDR_EVERY_MS:
        percent = light_percent(read_average())
        set_brightness(percent)
        print("light:", percent)
        last_read = ticks_ms()

# ---- 5  MAIN LOOP ----------------------------------------------------
while True:
    look_at_buttons()
    beat_if_due()
    read_light_if_due()
    sleep_ms(LOOP_MS)
