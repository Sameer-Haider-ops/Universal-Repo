# naive.py -- one loop that does everything. Given to you for Session 17.
# Standard layout, five sections, in order.

# ---- 1  IMPORTS ------------------------------------------------------
from machine import ADC, Pin, PWM
from time import sleep_ms, ticks_ms, ticks_diff

# ---- 2  CONSTANTS ----------------------------------------------------
LED_PIN        = 17     # YOUR LED's GPIO number, from your main.py
BRIGHTER_PIN   = 16     # YOUR brighter button's GPIO number, from your main.py
DIMMER_PIN     = 21     # YOUR dimmer button's GPIO number, from your main.py
LDR_PIN        = 27     # GP27, physical pin 32
PWM_FREQ       = 1000   # YOUR LED's PWM frequency, in Hz
LEVELS         = [0, 5, 15, 40, 100]   # YOUR levels from Session 11
DARK           = 3000   # YOUR covered count from Session 12
BRIGHT         = 60000  # YOUR flashlight count from Session 12
DEBOUNCE_MS    = 40     # Stable time required to filter out mechanical bounce
HEARTBEAT_MS   = 500    # how often the heartbeat should flip
LDR_EVERY_MS   = 600    # how long after one LDR reading the next is due
N_AVERAGE      = 10     # readings averaged into one LDR reading
AVERAGE_GAP_MS = 30     # pause between those readings
LOOP_MS        = 10     # pause at the end of every trip round the loop
OVERRIDE_MS    = 5000   # Time in ms to stay in manual mode after last button press

# ---- 3  SETUP --------------------------------------------------------
led      = PWM(Pin(LED_PIN))
led.freq(PWM_FREQ)
brighter = Pin(BRIGHTER_PIN, Pin.IN, Pin.PULL_UP)
dimmer   = Pin(DIMMER_PIN, Pin.IN, Pin.PULL_UP)
ldr      = ADC(Pin(LDR_PIN))
heart    = Pin("LED", Pin.OUT)       # the on-board LED

level_index       = 0                # which of LEVELS the buttons chose
taps              = 0                # button presses this program has seen

# Debounce tracking variables
b_last_raw        = brighter.value()
b_stable_state    = brighter.value()
b_last_change     = ticks_ms()

d_last_raw        = dimmer.value()
d_stable_state    = dimmer.value()
d_last_change     = ticks_ms()

last_beat         = ticks_ms()       # when the heartbeat last flipped
last_read         = ticks_ms()       # when the LDR was last read
manual_override   = False            # Start with LDR in control
last_button_time  = ticks_ms()       # Timestamp of the last button press

# ---- 4  FUNCTIONS ----------------------------------------------------
def set_brightness(level):           # 0 to 100, the same job as yours
    led.duty_u16(int(level * 65535 / 100))

def light_percent(counts):           # 0 at DARK, 100 at BRIGHT, clamped
    if counts <= DARK:
        return 0
    if counts >= BRIGHT:
        return 100
    return (counts - DARK) * 100 / (BRIGHT - DARK)

def read_average():                  # the mean of N_AVERAGE readings
    total = 0
    for i in range(N_AVERAGE):
        total = total + ldr.read_u16()
        sleep_ms(AVERAGE_GAP_MS)
    return total / N_AVERAGE

def step(direction):                 # one level up (+1) or down (-1)
    global level_index, taps, manual_override, last_button_time, last_read
    level_index = level_index + direction
    if level_index < 0:
        level_index = 0
    if level_index > len(LEVELS) - 1:
        level_index = len(LEVELS) - 1
    taps = taps + 1
    
    # Button priority execution
    set_brightness(LEVELS[level_index])
    print("button:", LEVELS[level_index], "   taps seen:", taps)
    
    # Activate manual override and reset timers
    manual_override = True
    last_button_time = ticks_ms()
    last_read = ticks_ms()

def look_at_buttons():               # Non-blocking debounced button checks
    global b_last_raw, b_stable_state, b_last_change
    global d_last_raw, d_stable_state, d_last_change
    
    now = ticks_ms()
    
    # --- Brighter Button Debounce ---
    b_raw = brighter.value()
    if b_raw != b_last_raw:
        b_last_raw = b_raw
        b_last_change = now
        
    if ticks_diff(now, b_last_change) >= DEBOUNCE_MS:
        if b_raw != b_stable_state:
            b_stable_state = b_raw
            if b_stable_state == 0:
                step(+1)

    # --- Dimmer Button Debounce ---
    d_raw = dimmer.value()
    if d_raw != d_last_raw:
        d_last_raw = d_raw
        d_last_change = now
        
    if ticks_diff(now, d_last_change) >= DEBOUNCE_MS:
        if d_raw != d_stable_state:
            d_stable_state = d_raw
            if d_stable_state == 0:
                step(-1)

def beat_if_due():                   # flip the heartbeat if it is time
    global last_beat
    now = ticks_ms()
    if ticks_diff(now, last_beat) >= HEARTBEAT_MS:
        heart.toggle()
        print("heartbeat period:", ticks_diff(now, last_beat), "ms") # Restored heartbeat print
        last_beat = now

def read_light_if_due():             # read LDR and set LED if due and override expired
    global last_read, manual_override, last_button_time
    now = ticks_ms()
    
    # Check if the 5-second manual override window has expired
    if manual_override and ticks_diff(now, last_button_time) >= OVERRIDE_MS:
        manual_override = False
        print("Manual override expired. Returning to LDR control.")

    # Read LDR when due
    if ticks_diff(now, last_read) >= LDR_EVERY_MS:
        if not manual_override:
            avg_counts = read_average()
            percent = light_percent(avg_counts)
            set_brightness(percent)
            print("light:", percent)
        last_read = now

# ---- 5  MAIN LOOP ----------------------------------------------------
while True:
    look_at_buttons()     # Buttons checked first (debounced + prioritized)
    beat_if_due()
    read_light_if_due()
    sleep_ms(LOOP_MS)