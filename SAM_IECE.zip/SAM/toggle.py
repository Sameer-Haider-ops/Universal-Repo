from machine import Pin,PWM
from utime import sleep
button_pin = 16
led_pin = 17
heart = Pin("LED", Pin.OUT)
button = Pin(button_pin , Pin.IN , Pin.PULL_UP)
led_pwm = PWM(Pin(led_pin))
led_pwm.freq(1000)
def set_brightness(duty_cycle):
    led_pwm.duty_u16(duty_cycle)

led_on = False

def on_press(pin):
    global presses , led_on
    led_on = not led_on
    if led_on:
        set_brightness(50)
    else:
        set_brightness(0)
    presses += 1
    print(presses)
button.irq(trigger=Pin.IRQ_FALLING, handler=on_press)

presses = 0
led_state = False
set_brightness(0)
last = button.value()
while True:
    now = button.value()
    heart.toggle()
    sleep(0.5)
    if last == 1 and now == 0:
        presses += 1
        led_state = not led_state
        set_brightness(65535 if led_state else 0)
        print("Presses:" , presses)
    last = now