from machine import Pin, I2C
from time import sleep
from bmp280 import BMP280
# -> CONSTANTS
SDA_PIN = 4 # GP4, physical pin 6
SCL_PIN = 5 # GP5, physical pin 7
I2C_FREQ = 100000 # 100 kHz
REG_RESET = 0xE0
REG_CTRL_MEAS = 0xF4
REG_TEMP = 0xFA # three bytes: 0xFA, 0xFB, 0xFC
BMP_ADDR = 0x76 # YOUR address, from Task 13.4
REG_ID = 0xD0
REG_CALIB = 0x88
# -> SETUP
i2c = I2C(0, sda=Pin(SDA_PIN), scl=Pin(SCL_PIN), freq=I2C_FREQ)
sensor = BMP280(i2c, BMP_ADDR)
print(list(i2c.readfrom_mem(BMP_ADDR, REG_CALIB, 2)))

# -> LOOP (runs once)
print(hex(i2c.scan()[0]))

 # the chip ID register
# -> LOOP (runs once)
while True:
    print(sensor.temperature, sensor.pressure / 100) # deg C, hPa
    sleep(1)
