from machine import Pin , PWM
from time import sleep
button = Pin(16 , Pin.IN , Pin.PULL_UP)

while True:
    if button.value() == 0:
        print("pressed")