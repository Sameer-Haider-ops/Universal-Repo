# test˙adc.py -- quick tests for today, not part of main.py
# -¿ IMPORTS
from machine import ADC, Pin
from time import sleep
# -¿ CONSTANTS
POT_PIN = 26 # GP26, physical pin 31
FULL_SCALE = 65535
V_REF = 3.3
# -¿ SETUP
pot = ADC(Pin(POT_PIN))
def counts_to_volts(counts):
    return counts * (V_REF / FULL_SCALE)

# -¿ LOOP
while True:
    counts = pot.read_u16()
    print(counts , ':' , counts_to_volts(counts) )
    