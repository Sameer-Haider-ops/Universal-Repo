# ---- 1 IMPORTS ------------------------------------------------------
from machine import Pin, PWM
from time import ticks_ms, ticks_diff
from drive_strength import set_drive_strength

# ---- 2 CONSTANTS: every number that means something, named once -----
LED_PIN        = 15      # YOUR LED's GPIO number, from its flag
BUTTON_PIN     = 14      # YOUR button's GPIO number, from its flag
DEBOUNCE_MS    = 20      # YOUR Session 10 DEBOUNCE_S, in milliseconds
HEARTBEAT_MS   = 500     # how often the heartbeat flips
PWM_FREQ       = 1000    # YOUR LED's PWM frequency, in Hz
DRIVE_STRENGTH = 12      # YOUR LED's drive strength, in mA
# YOUR other constants from previous sessions go here too

# ---- 3 SETUP: every Pin and PWM created here, once ------------------
# YOUR LED's PWM object, your one set_drive_strength(), and setting frequency call go here
button = Pin(BUTTON_PIN, Pin.IN, Pin.PULL_UP)
heart = Pin("LED", Pin.OUT)       # the on-board LED

presses = 0
led_on = False
last_beat = ticks_ms()            # when the heartbeat last flipped
edge_seen = False                 # the flag: the handler saw an edge
last_edge = ticks_ms()            # when it saw the most recent one
stable = button.value()           # the last reading the loop trusted

# ---- 4 FUNCTIONS: each does one job you can say in a sentence -------
def set_brightness(level):
    ...        # YOUR function from Session 9

def toggle_and_count():
    global presses, led_on
    ...        # YOUR toggle and count from Session 10

def beat_if_due():                # flip the heartbeat if it is time
    global last_beat
    if ticks_diff(ticks_ms(), last_beat) >= HEARTBEAT_MS:
        heart.toggle()
        last_beat = ticks_ms()

def on_edge(pin):                 # the handler: note WHEN, nothing else
    global edge_seen, last_edge
    last_edge = ticks_ms()
    edge_seen = True

def pressed():                    # True once per press, after the bounce
    global edge_seen, stable
    if edge_seen and ticks_diff(ticks_ms(), last_edge) >= DEBOUNCE_MS:
        edge_seen = False
        now = button.value()
        if now != stable:
            stable = now
            if now == 0:          # it settled pressed
                return True
    return False

# ---- 5 MAIN LOOP: should read like a description of the behaviour ---
# attach the handler once, here: on_edge must already be defined above.
# Both edges, so the handler hears the bounce on press AND on release
button.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=on_edge)
while True:
    beat_if_due()
    if pressed():
        toggle_and_count()