# report.py -- the BMP280 on its own, reported on a timer
# ---- 1 IMPORTS ------------------------------------------------------
from machine import Pin, I2C, Timer
from bmp280 import BMP280
# ---- 2 CONSTANTS ----------------------------------------------------
SDA_PIN = 4 # GP4, physical pin 6
SCL_PIN = 5 # GP5, physical pin 7
I2C_FREQ = 100000 # 100 kHz
BMP_ADDR = 0x76 # YOUR address, from Task 13.4
REPORT_MS = 1000 # YOUR choice: how often to report
# ---- 3 SETUP --------------------------------------------------------
i2c = I2C(0, sda=Pin(SDA_PIN), scl=Pin(SCL_PIN), freq=I2C_FREQ)
sensor = BMP280(i2c, BMP_ADDR) # one sensor object, created once
report_due = False # the flag: a report is due
# ---- 4 FUNCTIONS ----------------------------------------------------
def report_tick(t): # timer callback: note it, nothing else
    global report_due
    report_due = True
def print_status(): # one line: deg C, hPa
    temp = sensor.temperature
    press = sensor.pressure / 100
    print(f"{temp:.2f} C, {press:.2f} hPa")
# ---- 5 MAIN LOOP ----------------------------------------------------
reporter = Timer(period=REPORT_MS, mode=Timer.PERIODIC, callback=report_tick)
while True:
    if report_due:
        report_due = False
        print_status()