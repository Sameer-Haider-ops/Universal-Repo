from machine import Pin , PWM
from machine import Pin
from utime import sleep

led = Pin(PWM(15))
led.freq(1000)
led.duty_u16()