from machine import Pin
from utime import sleep
from drive_strength import set_drive_strength
from machine import Pin , PWM
drive = Pin(15 , Pin.OUT)
def lights_off():
    drive.value(0)
def lights_on():
    drive.value(1)
# set_drive_strength(15,12)
led = PWM(Pin(15))
# def min():
#     lights_on()
#     sleep(0.1)
#     lights_off()
#     sleep(0.1)
# def max():
#         lights_on()
#         sleep(0.6)
#         lights_off()
#         sleep(0.1)
def set_brightness():
    while True:
            led.freq(1000)
            # for i in range(0, 65535,500):
            #     led.duty_u16(i)
            #     sleep(0.1)
            # for j in range(65535 , 0 , -500):
            #      led.duty_u16(j)
            #      sleep(0.1)
            led.duty_u16(47000)
    # while True:
    #     try:
    #         lights_on()
    #         sleep(Ontime)
    #         lights_off()
    #         sleep(offtime)
            # lights_on()
            # sleep(n)
            # lights_off()
            # sleep(n)
            # lights_on()
            # sleep(n)
            # lights_off()
            # sleep(n)
            # min()
            # min()
            #  max()

        # except KeyboardInterrupt:
        #     break
set_brightness()
# drive.off()
