# scope_bus.py -- keep the I2C bus busy for the oscilloscope
# -> IMPORTS
from machine import Pin, I2C
from time import sleep
# -> CONSTANTS
SDA_PIN = 4 # GP4, physical pin 6
SCL_PIN = 5 # GP5, physical pin 7
I2C_FREQ = 100000 # 100 kHz
BMP_ADDR = 0x76 # YOUR address, from Task 13.4
REG_ID = 0xD0
PAUSE_S = 0.1 # seconds between conversations
# -> SETUP
i2c = I2C(0, sda=Pin(SDA_PIN), scl=Pin(SCL_PIN), freq=I2C_FREQ)
# -> LOOP
while True:
    i2c.readfrom_mem(BMP_ADDR, REG_ID, 1)
    sleep(PAUSE_S)
