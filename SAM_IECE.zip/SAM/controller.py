# 1 IMPORTS
from machine import Pin, PWM , ADC , Timer
from time import ticks_ms, ticks_diff
from drive_strength import set_drive_strength

# 2 CONSTANTS
LED_PIN = 17
BRIGHTER_PIN = 16
DIMMER_PIN = 21
DEBOUNCE_MS = 20
HEARTBEAT_MS = 500
PWM_FREQ = 1000
LEVELS = [0, 5, 15, 32, 60, 100]
POT_PIN = 26
FULL_SCALE = 65535
V_REF = 3.3
DARK = 3000
LDR_PIN = 27
BRIGHT = 60000
HEARTBEAT_MS = 500
SAMPLE_MS = 100

# 3 SETUP
led_pwm = PWM(Pin(LED_PIN))
led_pwm.freq(PWM_FREQ)

btn_brighter = Pin(BRIGHTER_PIN, Pin.IN, Pin.PULL_UP)
btn_dimmer = Pin(DIMMER_PIN, Pin.IN, Pin.PULL_UP)
heart = Pin("LED", Pin.OUT)
pot = ADC(Pin(POT_PIN))
ldr = ADC(Pin(LDR_PIN))
current_index = 0
last_beat = ticks_ms()
fresh = False
latest = 0

# Brighter button state variables
b_edge_seen = False
b_last_edge = ticks_ms()
b_stable = btn_brighter.value()

# Dimmer button state variables
d_edge_seen = False
d_last_edge = ticks_ms()
d_stable = btn_dimmer.value()

# 4 FUNCTIONS
def set_brightness(level):
    duty = int((level / 100) * 65535)
    led_pwm.duty_u16(duty)

def beat(t):
    heart.toggle()

def sample(t):
    global latest, fresh
    latest = ldr.read_u16()
    fresh = True

def step(direction):
    global current_index
    current_index += direction
    if current_index < 0:
        current_index = 0
    elif current_index >= len(LEVELS):
        current_index = len(LEVELS) - 1
    
    set_brightness(LEVELS[current_index])
    print(f"Level index: {current_index}, Brightness: {LEVELS[current_index]}%")

def beat_if_due():
    global last_beat
    if ticks_diff(ticks_ms(), last_beat) >= HEARTBEAT_MS:
        heart.toggle()
        last_beat = ticks_ms()

def on_brighter_edge(pin):
    global b_edge_seen, b_last_edge
    b_last_edge = ticks_ms()
    b_edge_seen = True

def on_dimmer_edge(pin):
    global d_edge_seen, d_last_edge
    d_last_edge = ticks_ms()
    d_edge_seen = True

def brighter_pressed():
    global b_edge_seen, b_stable
    if b_edge_seen and ticks_diff(ticks_ms(), b_last_edge) >= DEBOUNCE_MS:
        b_edge_seen = False
        now = btn_brighter.value()
        if now != b_stable:
            b_stable = now
            if now == 0:
                return True
    return False

def dimmer_pressed():
    global d_edge_seen, d_stable
    if d_edge_seen and ticks_diff(ticks_ms(), d_last_edge) >= DEBOUNCE_MS:
        d_edge_seen = False
        now = btn_dimmer.value()
        if now != d_stable:
            d_stable = now
            if now == 0:
                return True
    return False

def light_percent(counts):
    if counts <= DARK:
        return 0
    if counts >= BRIGHT:
        return 100
    return (counts - DARK) * 100 / (BRIGHT - DARK)


def counts_to_volts(counts):
    return counts * (V_REF / FULL_SCALE)

def knob_percent():
    counts = pot.read_u16()
    return counts * 100 / FULL_SCALE



# 5 MAIN LOOP
btn_brighter.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=on_brighter_edge)
btn_dimmer.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=on_dimmer_edge)
heartbeat = Timer(period=HEARTBEAT_MS, mode=Timer.PERIODIC, callback=beat)
sampler = Timer(period=SAMPLE_MS, mode=Timer.PERIODIC, callback=sample)



set_brightness(LEVELS[current_index])

while True:
    # beat_if_due()
    # if brighter_pressed():
    #     step(+1)
    # if dimmer_pressed():
        #     step(-1)
    # set_brightness(knob_percent())
    if fresh:
        fresh = False
        set_brightness(100 - light_percent(latest))  # night-light



